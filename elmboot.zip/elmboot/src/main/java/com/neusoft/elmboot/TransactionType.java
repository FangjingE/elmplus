package com.neusoft.elmboot;

public enum TransactionType {
    DEBIT,CREDIT,TRANSFER
}
